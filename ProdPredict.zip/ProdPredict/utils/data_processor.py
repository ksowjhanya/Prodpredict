import pandas as pd
import numpy as np
from datetime import datetime
import streamlit as st
import json
import xml.etree.ElementTree as ET
from io import StringIO

class DataProcessor:
    """
    Data processing utilities for employee productivity data
    """
    
    def __init__(self):
        self.required_columns = ['employee_id', 'date', 'productivity_score']
        self.optional_columns = ['department', 'hours_worked', 'tasks_completed', 
                               'efficiency_rating', 'project_deadline', 'team_size',
                               'project_complexity', 'skill_level', 'experience_years',
                               'training_hours', 'overtime_hours', 'break_time',
                               'collaboration_score', 'innovation_score']
        self.supported_formats = ['csv', 'xlsx', 'xls', 'json', 'xml', 'tsv', 'txt']
    
    def preprocess_data(self, df):
        """
        Preprocess the uploaded data for ML training
        
        Args:
            df: Raw pandas DataFrame
            
        Returns:
            Processed DataFrame or None if validation fails
        """
        try:
            # Make a copy to avoid modifying original
            processed_df = df.copy()
            
            # Validate required columns
            missing_cols = [col for col in self.required_columns if col not in processed_df.columns]
            if missing_cols:
                st.error(f"Missing required columns: {missing_cols}")
                return None
            
            # Convert date column
            processed_df['date'] = pd.to_datetime(processed_df['date'])
            
            # Clean productivity score
            processed_df['productivity_score'] = pd.to_numeric(
                processed_df['productivity_score'], errors='coerce'
            )
            
            # Remove rows with invalid productivity scores
            before_clean = len(processed_df)
            processed_df = processed_df.dropna(subset=['productivity_score'])
            after_clean = len(processed_df)
            
            if before_clean != after_clean:
                st.warning(f"Removed {before_clean - after_clean} rows with invalid productivity scores")
            
            # Validate productivity score range (assuming 0-100 scale)
            invalid_scores = processed_df[
                (processed_df['productivity_score'] < 0) | 
                (processed_df['productivity_score'] > 100)
            ]
            
            if len(invalid_scores) > 0:
                st.warning(f"Found {len(invalid_scores)} productivity scores outside 0-100 range")
                # Cap the values
                processed_df['productivity_score'] = processed_df['productivity_score'].clip(0, 100)
            
            # Handle optional columns
            if 'department' not in processed_df.columns:
                processed_df['department'] = 'Unknown'
            
            if 'hours_worked' not in processed_df.columns:
                processed_df['hours_worked'] = 8.0  # Default 8 hours
            else:
                processed_df['hours_worked'] = pd.to_numeric(
                    processed_df['hours_worked'], errors='coerce'
                ).fillna(8.0)
            
            if 'tasks_completed' not in processed_df.columns:
                processed_df['tasks_completed'] = processed_df['productivity_score'] / 10  # Rough estimate
            else:
                processed_df['tasks_completed'] = pd.to_numeric(
                    processed_df['tasks_completed'], errors='coerce'
                ).fillna(processed_df['productivity_score'] / 10)
            
            if 'efficiency_rating' not in processed_df.columns:
                processed_df['efficiency_rating'] = processed_df['productivity_score'] / 20  # Scale to 1-5
            else:
                processed_df['efficiency_rating'] = pd.to_numeric(
                    processed_df['efficiency_rating'], errors='coerce'
                ).fillna(processed_df['productivity_score'] / 20)
            
            # Create time-based features
            processed_df['day_of_week'] = processed_df['date'].dt.dayofweek
            processed_df['month'] = processed_df['date'].dt.month
            processed_df['quarter'] = processed_df['date'].dt.quarter
            processed_df['week_of_year'] = processed_df['date'].dt.isocalendar().week
            
            # Create rolling averages (if enough data)
            if len(processed_df) > 7:
                processed_df = processed_df.sort_values(['employee_id', 'date'])
                processed_df['productivity_7day_avg'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=7, min_periods=1).mean()
                )
                processed_df['productivity_30day_avg'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=30, min_periods=1).mean()
                )
            else:
                processed_df['productivity_7day_avg'] = processed_df['productivity_score']
                processed_df['productivity_30day_avg'] = processed_df['productivity_score']
            
            # Employee-level statistics
            employee_stats = processed_df.groupby('employee_id')['productivity_score'].agg([
                'mean', 'std', 'min', 'max'
            ]).reset_index()
            employee_stats.columns = ['employee_id', 'employee_avg_productivity', 
                                    'employee_productivity_std', 'employee_min_productivity', 
                                    'employee_max_productivity']
            
            processed_df = processed_df.merge(employee_stats, on='employee_id', how='left')
            
            # Fill NaN values in std (for employees with single record)
            processed_df['employee_productivity_std'] = processed_df['employee_productivity_std'].fillna(0)
            
            # Sort by date for consistency
            processed_df = processed_df.sort_values(['employee_id', 'date']).reset_index(drop=True)
            
            st.success(f"✅ Data preprocessing completed. Final shape: {processed_df.shape}")
            
            return processed_df
            
        except Exception as e:
            st.error(f"Error in data preprocessing: {str(e)}")
            return None
    
    def generate_quality_report(self, df):
        """
        Generate a data quality report
        
        Args:
            df: Processed DataFrame
            
        Returns:
            Dictionary with quality metrics
        """
        try:
            report = {
                "total_records": len(df),
                "unique_employees": df['employee_id'].nunique(),
                "date_range": {
                    "start": df['date'].min().strftime('%Y-%m-%d'),
                    "end": df['date'].max().strftime('%Y-%m-%d'),
                    "days_covered": (df['date'].max() - df['date'].min()).days
                },
                "productivity_stats": {
                    "mean": round(df['productivity_score'].mean(), 2),
                    "median": round(df['productivity_score'].median(), 2),
                    "std": round(df['productivity_score'].std(), 2),
                    "min": round(df['productivity_score'].min(), 2),
                    "max": round(df['productivity_score'].max(), 2)
                },
                "missing_values": df.isnull().sum().to_dict(),
                "data_completeness": {
                    "percentage_complete": round((1 - df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100, 2)
                }
            }
            
            # Add department info if available
            if 'department' in df.columns:
                report["departments"] = {
                    "unique_count": df['department'].nunique(),
                    "distribution": df['department'].value_counts().to_dict()
                }
            
            return report
            
        except Exception as e:
            return {"error": f"Failed to generate quality report: {str(e)}"}
    
    def validate_prediction_data(self, df, required_features):
        """
        Validate data for prediction
        
        Args:
            df: DataFrame to validate
            required_features: List of required feature names
            
        Returns:
            Boolean indicating if data is valid
        """
        try:
            missing_features = [feat for feat in required_features if feat not in df.columns]
            if missing_features:
                st.error(f"Missing features for prediction: {missing_features}")
                return False
            
            # Check for missing values in required features
            missing_values = df[required_features].isnull().sum()
            if missing_values.sum() > 0:
                st.warning(f"Found missing values in features: {missing_values[missing_values > 0].to_dict()}")
            
            return True
            
        except Exception as e:
            st.error(f"Validation error: {str(e)}")
            return False
    
    def load_file(self, uploaded_file):
        """
        Load data from various file formats
        
        Args:
            uploaded_file: Streamlit uploaded file object
            
        Returns:
            DataFrame or None if loading fails
        """
        try:
            file_extension = uploaded_file.name.split('.')[-1].lower()
            
            if file_extension == 'csv':
                # Try different encodings and separators
                try:
                    df = pd.read_csv(uploaded_file, encoding='utf-8')
                except UnicodeDecodeError:
                    uploaded_file.seek(0)
                    df = pd.read_csv(uploaded_file, encoding='latin-1')
                    
            elif file_extension in ['xlsx', 'xls']:
                df = pd.read_excel(uploaded_file)
                
            elif file_extension == 'json':
                data = json.load(uploaded_file)
                if isinstance(data, list):
                    df = pd.DataFrame(data)
                elif isinstance(data, dict):
                    if 'data' in data:
                        df = pd.DataFrame(data['data'])
                    else:
                        df = pd.DataFrame([data])
                else:
                    raise ValueError("Invalid JSON structure")
                    
            elif file_extension == 'xml':
                content = uploaded_file.read()
                root = ET.fromstring(content)
                data = []
                
                # Try to parse common XML structures
                for record in root.findall('.//record') or root.findall('.//employee') or root.findall('.//row'):
                    row_data = {}
                    for child in record:
                        row_data[child.tag] = child.text
                    data.append(row_data)
                    
                if not data:
                    # Fallback: try to parse flat structure
                    for child in root:
                        if len(list(child)) > 0:
                            row_data = {}
                            for subchild in child:
                                row_data[subchild.tag] = subchild.text
                            data.append(row_data)
                            
                df = pd.DataFrame(data)
                
            elif file_extension == 'tsv':
                df = pd.read_csv(uploaded_file, sep='\t')
                
            elif file_extension == 'txt':
                # Try to detect delimiter
                content = StringIO(uploaded_file.read().decode('utf-8'))
                sample = content.read(1024)
                content.seek(0)
                
                if '\t' in sample:
                    df = pd.read_csv(content, sep='\t')
                elif ';' in sample:
                    df = pd.read_csv(content, sep=';')
                elif '|' in sample:
                    df = pd.read_csv(content, sep='|')
                else:
                    df = pd.read_csv(content)
                    
            else:
                raise ValueError(f"Unsupported file format: {file_extension}")
                
            st.success(f"Successfully loaded {file_extension.upper()} file with {len(df)} records")
            return df
            
        except Exception as e:
            st.error(f"Error loading file: {str(e)}")
            return None
    
    def advanced_feature_engineering(self, df):
        """
        Create advanced features for complex analysis
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with advanced features
        """
        try:
            processed_df = df.copy()
            
            # Time-based advanced features
            processed_df['is_weekend'] = processed_df['date'].dt.dayofweek >= 5
            processed_df['is_month_end'] = processed_df['date'].dt.day >= 25
            processed_df['is_quarter_end'] = processed_df['date'].dt.month.isin([3, 6, 9, 12])
            processed_df['days_since_start'] = (processed_df['date'] - processed_df['date'].min()).dt.days
            
            # Productivity momentum features
            processed_df = processed_df.sort_values(['employee_id', 'date'])
            processed_df['productivity_lag1'] = processed_df.groupby('employee_id')['productivity_score'].shift(1)
            processed_df['productivity_lag7'] = processed_df.groupby('employee_id')['productivity_score'].shift(7)
            processed_df['productivity_momentum'] = processed_df['productivity_score'] - processed_df['productivity_lag1']
            processed_df['productivity_trend'] = processed_df['productivity_score'] - processed_df['productivity_lag7']
            
            # Rolling statistics (multiple windows)
            for window in [3, 7, 14, 30]:
                processed_df[f'productivity_{window}d_mean'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=window, min_periods=1).mean()
                )
                processed_df[f'productivity_{window}d_std'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=window, min_periods=1).std()
                ).fillna(0)
                processed_df[f'productivity_{window}d_min'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=window, min_periods=1).min()
                )
                processed_df[f'productivity_{window}d_max'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                    lambda x: x.rolling(window=window, min_periods=1).max()
                )
            
            # Comparative features
            processed_df['dept_avg_productivity'] = processed_df.groupby(['department', 'date'])['productivity_score'].transform('mean')
            processed_df['relative_to_dept'] = processed_df['productivity_score'] - processed_df['dept_avg_productivity']
            processed_df['global_avg_productivity'] = processed_df.groupby('date')['productivity_score'].transform('mean')
            processed_df['relative_to_global'] = processed_df['productivity_score'] - processed_df['global_avg_productivity']
            
            # Volatility and consistency metrics
            processed_df['productivity_volatility'] = processed_df.groupby('employee_id')['productivity_score'].transform(
                lambda x: x.rolling(window=30, min_periods=5).std()
            ).fillna(0)
            processed_df['consistency_score'] = 100 - processed_df['productivity_volatility']
            
            # Performance categorization
            processed_df['performance_category'] = pd.cut(
                processed_df['productivity_score'], 
                bins=[0, 50, 70, 85, 95, 100], 
                labels=['Poor', 'Below Average', 'Average', 'Good', 'Excellent']
            )
            
            # Advanced optional feature engineering
            if 'hours_worked' in processed_df.columns:
                processed_df['productivity_per_hour'] = processed_df['productivity_score'] / processed_df['hours_worked'].clip(lower=1)
                processed_df['overtime_flag'] = processed_df['hours_worked'] > 8
                processed_df['efficiency_ratio'] = processed_df['productivity_score'] / (processed_df['hours_worked'] * 10)
            
            if 'tasks_completed' in processed_df.columns:
                processed_df['productivity_per_task'] = processed_df['productivity_score'] / processed_df['tasks_completed'].clip(lower=1)
                processed_df['task_efficiency'] = processed_df['tasks_completed'] / processed_df.get('hours_worked', 8)
            
            # Team and collaboration features
            if 'team_size' in processed_df.columns:
                processed_df['team_productivity_impact'] = processed_df['productivity_score'] / processed_df['team_size'].clip(lower=1)
            
            # Experience and skill impact
            if 'experience_years' in processed_df.columns:
                processed_df['experience_productivity_ratio'] = processed_df['productivity_score'] / processed_df['experience_years'].clip(lower=0.5)
                processed_df['is_senior'] = processed_df['experience_years'] >= 5
            
            # Remove infinite and NaN values
            processed_df = processed_df.replace([np.inf, -np.inf], np.nan)
            numeric_columns = processed_df.select_dtypes(include=[np.number]).columns
            processed_df[numeric_columns] = processed_df[numeric_columns].fillna(processed_df[numeric_columns].median())
            
            return processed_df
            
        except Exception as e:
            st.error(f"Error in advanced feature engineering: {str(e)}")
            return df
