import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor, ExtraTreesRegressor, VotingRegressor, BaggingRegressor
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score, TimeSeriesSplit
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, RobustScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, mean_absolute_percentage_error
from sklearn.feature_selection import SelectKBest, f_regression, RFE
import xgboost as xgb
try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except (ImportError, OSError):
    LIGHTGBM_AVAILABLE = False
    lgb = None
import joblib
from datetime import datetime, timedelta
import streamlit as st
import warnings
warnings.filterwarnings('ignore')

class ProductivityPredictor:
    """
    Machine Learning models for productivity prediction
    """
    
    def __init__(self):
        self.model = None
        self.feature_names = None
        self.label_encoders = {}
        self.model_type = None
        self.scaler = None
        self.feature_selector = None
        self.ensemble_models = {}
        self.model_params = {}
        self.available_models = {
            'random_forest': 'Random Forest',
            'gradient_boosting': 'Gradient Boosting',
            'xgboost': 'XGBoost',
            'extra_trees': 'Extra Trees',
            'linear_regression': 'Linear Regression',
            'ridge_regression': 'Ridge Regression',
            'lasso_regression': 'Lasso Regression',
            'elastic_net': 'Elastic Net',
            'svr': 'Support Vector Regression',
            'neural_network': 'Neural Network',
            'ensemble_voting': 'Ensemble (Voting)',
            'ensemble_bagging': 'Ensemble (Bagging)'
        }
        
        if LIGHTGBM_AVAILABLE:
            self.available_models['lightgbm'] = 'LightGBM'
    
    def prepare_features(self, df):
        """
        Prepare features for ML training/prediction
        
        Args:
            df: Input DataFrame
            
        Returns:
            Feature DataFrame and target series
        """
        try:
            # Copy data to avoid modifications
            data = df.copy()
            
            # Select numeric and categorical features
            numeric_features = [
                'hours_worked', 'tasks_completed', 'efficiency_rating',
                'day_of_week', 'month', 'quarter', 'week_of_year',
                'productivity_7day_avg', 'productivity_30day_avg',
                'employee_avg_productivity', 'employee_productivity_std',
                'employee_min_productivity', 'employee_max_productivity'
            ]
            
            categorical_features = ['department']
            
            # Ensure all numeric features exist
            for feature in numeric_features:
                if feature not in data.columns:
                    data[feature] = 0
            
            # Ensure categorical features exist
            for feature in categorical_features:
                if feature not in data.columns:
                    data[feature] = 'Unknown'
            
            # Encode categorical features
            for feature in categorical_features:
                if feature not in self.label_encoders:
                    self.label_encoders[feature] = LabelEncoder()
                    data[f'{feature}_encoded'] = self.label_encoders[feature].fit_transform(data[feature].astype(str))
                else:
                    # Handle unseen categories
                    known_categories = set(self.label_encoders[feature].classes_)
                    data[feature] = data[feature].astype(str)
                    
                    # Replace unknown categories with most frequent
                    unknown_mask = ~data[feature].isin(known_categories)
                    if unknown_mask.any():
                        most_frequent = data[feature].mode()[0] if len(data[feature].mode()) > 0 else 'Unknown'
                        data.loc[unknown_mask, feature] = most_frequent
                    
                    data[f'{feature}_encoded'] = self.label_encoders[feature].transform(data[feature])
            
            # Create feature matrix
            feature_columns = numeric_features + [f'{cat}_encoded' for cat in categorical_features]
            X = data[feature_columns].fillna(0)
            
            # Target variable
            y = data['productivity_score'] if 'productivity_score' in data.columns else None
            
            return X, y, feature_columns
            
        except Exception as e:
            st.error(f"Error preparing features: {str(e)}")
            return None, None, None
    
    def train_model(self, df, model_type='random_forest', test_size=0.2, random_state=42, 
                   use_feature_selection=True, use_scaling=True, hyperparameter_tuning=False):
        """
        Train advanced ML model for productivity prediction
        
        Args:
            df: Training DataFrame
            model_type: Model type from available_models
            test_size: Proportion of data for testing
            random_state: Random seed
            use_feature_selection: Whether to use feature selection
            use_scaling: Whether to scale features
            hyperparameter_tuning: Whether to perform hyperparameter tuning
            
        Returns:
            Dictionary with model and performance metrics
        """
        try:
            # Prepare features
            X, y, feature_names = self.prepare_features(df)
            
            if X is None or y is None:
                return None
            
            # Feature selection
            if use_feature_selection and len(feature_names) > 20:
                k_best = min(20, len(feature_names) - 1)
                self.feature_selector = SelectKBest(score_func=f_regression, k=k_best)
                X = self.feature_selector.fit_transform(X, y)
                
                # Update feature names
                selected_features = self.feature_selector.get_support()
                feature_names = [name for i, name in enumerate(feature_names) if selected_features[i]]
                st.info(f"Selected top {k_best} features out of {len(selected_features)} total features")
            
            # Feature scaling
            if use_scaling and model_type in ['svr', 'neural_network', 'linear_regression', 'ridge_regression', 'lasso_regression', 'elastic_net']:
                self.scaler = StandardScaler()
                X = self.scaler.fit_transform(X)
            
            # Time series split for better validation
            if len(df) > 100:
                tscv = TimeSeriesSplit(n_splits=5)
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=random_state
                )
            else:
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y, test_size=test_size, random_state=random_state
                )
            
            # Initialize model with hyperparameters
            model = self._get_model(model_type, random_state, hyperparameter_tuning)
            
            if model is None:
                return None
            
            # Train model
            if hyperparameter_tuning and model_type in ['random_forest', 'gradient_boosting', 'xgboost']:
                model = self._perform_hyperparameter_tuning(model, X_train, y_train, model_type)
            
            model.fit(X_train, y_train)
            
            # Make predictions
            y_pred = model.predict(X_test)
            y_train_pred = model.predict(X_train)
            
            # Calculate comprehensive metrics
            metrics = self._calculate_metrics(y_test, y_pred, y_train, y_train_pred)
            
            # Cross-validation scores
            if len(df) > 50:
                cv_scores = cross_val_score(model, X_train, y_train, cv=5, scoring='r2')
                metrics['cv_r2_mean'] = cv_scores.mean()
                metrics['cv_r2_std'] = cv_scores.std()
            
            # Feature importance (if available)
            feature_importance = None
            if hasattr(model, 'feature_importances_'):
                feature_importance = model.feature_importances_
            elif hasattr(model, 'coef_'):
                feature_importance = np.abs(model.coef_)
            
            # Store model and metadata
            self.model = model
            self.feature_names = feature_names
            self.model_type = model_type
            
            results = {
                'model': model,
                'scaler': self.scaler,
                'feature_selector': self.feature_selector,
                'feature_names': feature_names,
                'feature_importance': feature_importance,
                'model_type': model_type,
                'y_test': y_test,
                'y_pred': y_pred,
                'y_train': y_train,
                'y_train_pred': y_train_pred,
                **metrics
            }
            
            return results
            
        except Exception as e:
            st.error(f"Error training model: {str(e)}")
            return None
    
    def _get_model(self, model_type, random_state, hyperparameter_tuning):
        """Get model instance based on type"""
        try:
            if model_type == 'random_forest':
                return RandomForestRegressor(
                    n_estimators=200 if hyperparameter_tuning else 100,
                    max_depth=15 if hyperparameter_tuning else 10,
                    min_samples_split=3,
                    min_samples_leaf=2,
                    random_state=random_state,
                    n_jobs=-1
                )
            elif model_type == 'gradient_boosting':
                return GradientBoostingRegressor(
                    n_estimators=200 if hyperparameter_tuning else 100,
                    max_depth=8 if hyperparameter_tuning else 6,
                    learning_rate=0.1,
                    min_samples_split=3,
                    min_samples_leaf=2,
                    random_state=random_state
                )
            elif model_type == 'xgboost':
                return xgb.XGBRegressor(
                    n_estimators=200 if hyperparameter_tuning else 100,
                    max_depth=8 if hyperparameter_tuning else 6,
                    learning_rate=0.1,
                    subsample=0.8,
                    colsample_bytree=0.8,
                    random_state=random_state,
                    n_jobs=-1
                )
            elif model_type == 'lightgbm':
                if LIGHTGBM_AVAILABLE:
                    return lgb.LGBMRegressor(
                        n_estimators=200 if hyperparameter_tuning else 100,
                        max_depth=8 if hyperparameter_tuning else 6,
                        learning_rate=0.1,
                        subsample=0.8,
                        colsample_bytree=0.8,
                        random_state=random_state,
                        n_jobs=-1,
                        verbose=-1
                    )
                else:
                    st.error("LightGBM not available. Please try another model.")
                    return None
            elif model_type == 'extra_trees':
                return ExtraTreesRegressor(
                    n_estimators=200 if hyperparameter_tuning else 100,
                    max_depth=15 if hyperparameter_tuning else 10,
                    min_samples_split=3,
                    min_samples_leaf=2,
                    random_state=random_state,
                    n_jobs=-1
                )
            elif model_type == 'linear_regression':
                return LinearRegression(n_jobs=-1)
            elif model_type == 'ridge_regression':
                return Ridge(alpha=1.0, random_state=random_state)
            elif model_type == 'lasso_regression':
                return Lasso(alpha=1.0, random_state=random_state)
            elif model_type == 'elastic_net':
                return ElasticNet(alpha=1.0, l1_ratio=0.5, random_state=random_state)
            elif model_type == 'svr':
                return SVR(kernel='rbf', C=1.0, gamma='scale')
            elif model_type == 'neural_network':
                return MLPRegressor(
                    hidden_layer_sizes=(100, 50),
                    activation='relu',
                    solver='adam',
                    alpha=0.001,
                    max_iter=500,
                    random_state=random_state
                )
            elif model_type == 'ensemble_voting':
                base_models = [
                    ('rf', RandomForestRegressor(n_estimators=100, random_state=random_state, n_jobs=-1)),
                    ('gb', GradientBoostingRegressor(n_estimators=100, random_state=random_state)),
                    ('xgb', xgb.XGBRegressor(n_estimators=100, random_state=random_state, n_jobs=-1))
                ]
                return VotingRegressor(estimators=base_models, n_jobs=-1)
            elif model_type == 'ensemble_bagging':
                base_model = RandomForestRegressor(n_estimators=50, random_state=random_state, n_jobs=-1)
                return BaggingRegressor(
                    base_estimator=base_model,
                    n_estimators=10,
                    random_state=random_state,
                    n_jobs=-1
                )
            else:
                st.error(f"Unsupported model type: {model_type}")
                return None
                
        except Exception as e:
            st.error(f"Error initializing model: {str(e)}")
            return None
    
    def _perform_hyperparameter_tuning(self, model, X_train, y_train, model_type):
        """Perform hyperparameter tuning"""
        try:
            if model_type == 'random_forest':
                param_grid = {
                    'n_estimators': [100, 200],
                    'max_depth': [10, 15, 20],
                    'min_samples_split': [2, 5],
                    'min_samples_leaf': [1, 2]
                }
            elif model_type == 'gradient_boosting':
                param_grid = {
                    'n_estimators': [100, 200],
                    'max_depth': [6, 8, 10],
                    'learning_rate': [0.05, 0.1, 0.2]
                }
            elif model_type == 'xgboost':
                param_grid = {
                    'n_estimators': [100, 200],
                    'max_depth': [6, 8, 10],
                    'learning_rate': [0.05, 0.1, 0.2],
                    'subsample': [0.8, 0.9]
                }
            else:
                return model
            
            grid_search = GridSearchCV(
                model, param_grid, cv=3, scoring='r2', n_jobs=-1, verbose=0
            )
            grid_search.fit(X_train, y_train)
            
            st.info(f"Best parameters: {grid_search.best_params_}")
            return grid_search.best_estimator_
            
        except Exception as e:
            st.warning(f"Hyperparameter tuning failed: {str(e)}. Using default parameters.")
            return model
    
    def _calculate_metrics(self, y_test, y_pred, y_train, y_train_pred):
        """Calculate comprehensive model metrics"""
        try:
            metrics = {
                'r2_score': r2_score(y_test, y_pred),
                'mae': mean_absolute_error(y_test, y_pred),
                'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
                'mape': mean_absolute_percentage_error(y_test, y_pred),
                'train_r2_score': r2_score(y_train, y_train_pred),
                'train_mae': mean_absolute_error(y_train, y_train_pred),
                'train_rmse': np.sqrt(mean_squared_error(y_train, y_train_pred))
            }
            
            # Calculate overfitting indicator
            metrics['overfitting_score'] = metrics['train_r2_score'] - metrics['r2_score']
            
            # Calculate model stability
            residuals = y_test - y_pred
            metrics['residual_std'] = np.std(residuals)
            metrics['residual_mean'] = np.mean(residuals)
            
            return metrics
            
        except Exception as e:
            st.error(f"Error calculating metrics: {str(e)}")
            return {}
    
    def generate_predictions(self, df, model, feature_names, days_ahead=30, 
                           employee_filter=None, department_filter=None):
        """
        Generate future productivity predictions
        
        Args:
            df: Historical data
            model: Trained model
            feature_names: List of feature names
            days_ahead: Number of days to predict
            employee_filter: List of employees to include
            department_filter: List of departments to include
            
        Returns:
            DataFrame with predictions
        """
        try:
            # Filter data if needed
            prediction_data = df.copy()
            
            if employee_filter:
                prediction_data = prediction_data[prediction_data['employee_id'].isin(employee_filter)]
            
            if department_filter and 'department' in prediction_data.columns:
                prediction_data = prediction_data[prediction_data['department'].isin(department_filter)]
            
            if len(prediction_data) == 0:
                st.warning("No data matches the selected filters")
                return None
            
            # Get the latest data for each employee
            latest_data = prediction_data.groupby('employee_id').last().reset_index()
            
            predictions_list = []
            
            for _, employee_data in latest_data.iterrows():
                for day in range(1, days_ahead + 1):
                    # Create future date
                    future_date = employee_data['date'] + timedelta(days=day)
                    
                    # Create prediction row
                    pred_row = employee_data.copy()
                    pred_row['date'] = future_date
                    pred_row['day_of_week'] = future_date.weekday()
                    pred_row['month'] = future_date.month
                    pred_row['quarter'] = (future_date.month - 1) // 3 + 1
                    pred_row['week_of_year'] = future_date.isocalendar()[1]
                    
                    # Convert to DataFrame for feature preparation
                    pred_df = pd.DataFrame([pred_row])
                    
                    # Prepare features
                    X_pred, _, _ = self.prepare_features(pred_df)
                    
                    if X_pred is not None and len(X_pred) > 0:
                        # Make prediction
                        predicted_score = model.predict(X_pred[feature_names])[0]
                        
                        # Determine risk level
                        if predicted_score < 70:
                            risk_level = 'High'
                        elif predicted_score < 85:
                            risk_level = 'Medium'
                        else:
                            risk_level = 'Low'
                        
                        predictions_list.append({
                            'employee_id': employee_data['employee_id'],
                            'department': employee_data.get('department', 'Unknown'),
                            'prediction_date': future_date,
                            'predicted_productivity': round(predicted_score, 2),
                            'risk_level': risk_level,
                            'confidence': min(100, max(0, 100 - abs(predicted_score - employee_data['productivity_score'])))
                        })
            
            if predictions_list:
                predictions_df = pd.DataFrame(predictions_list)
                return predictions_df
            else:
                st.warning("No predictions could be generated")
                return None
                
        except Exception as e:
            st.error(f"Error generating predictions: {str(e)}")
            return None
    
    def save_model(self, filepath):
        """Save trained model to file"""
        try:
            model_data = {
                'model': self.model,
                'feature_names': self.feature_names,
                'label_encoders': self.label_encoders,
                'model_type': self.model_type
            }
            joblib.dump(model_data, filepath)
            return True
        except Exception as e:
            st.error(f"Error saving model: {str(e)}")
            return False
    
    def load_model(self, filepath):
        """Load trained model from file"""
        try:
            model_data = joblib.load(filepath)
            self.model = model_data['model']
            self.feature_names = model_data['feature_names']
            self.label_encoders = model_data['label_encoders']
            self.model_type = model_data['model_type']
            return True
        except Exception as e:
            st.error(f"Error loading model: {str(e)}")
            return False
