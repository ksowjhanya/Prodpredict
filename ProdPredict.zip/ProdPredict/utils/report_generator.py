import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import base64
from io import BytesIO
import json

class ReportGenerator:
    """
    Generate comprehensive reports for productivity forecasting
    """
    
    def __init__(self):
        self.report_types = {
            'productivity_forecast': 'Productivity Forecast Report',
            'risk_analysis': 'Risk Analysis Report',
            'performance_summary': 'Performance Summary Report',
            'advanced_analytics': 'Advanced Analytics Report',
            'departmental_analysis': 'Departmental Performance Analysis',
            'trend_analysis': 'Trend & Seasonality Analysis',
            'predictive_insights': 'Predictive Insights & Recommendations',
            'executive_summary': 'Executive Summary Dashboard',
            'employee_spotlight': 'Employee Performance Spotlight',
            'comparative_analysis': 'Comparative Performance Analysis'
        }
    
    def generate_report_data(self, predictions_df, historical_df, report_type, date_range=None):
        """
        Generate report data based on type
        
        Args:
            predictions_df: DataFrame with predictions
            historical_df: DataFrame with historical data
            report_type: Type of report to generate
            date_range: Tuple of start and end dates
            
        Returns:
            DataFrame with report data
        """
        try:
            if date_range and len(date_range) == 2:
                # Filter predictions by date range
                filtered_predictions = predictions_df[
                    (predictions_df['prediction_date'].dt.date >= date_range[0]) &
                    (predictions_df['prediction_date'].dt.date <= date_range[1])
                ].copy()
            else:
                filtered_predictions = predictions_df.copy()
            
            if report_type == 'productivity_forecast':
                return self._generate_forecast_report(filtered_predictions, historical_df)
            elif report_type == 'risk_analysis':
                return self._generate_risk_report(filtered_predictions, historical_df)
            elif report_type == 'performance_summary':
                return self._generate_performance_report(filtered_predictions, historical_df)
            elif report_type == 'advanced_analytics':
                return self._generate_advanced_analytics_report(filtered_predictions, historical_df)
            elif report_type == 'departmental_analysis':
                return self._generate_departmental_report(filtered_predictions, historical_df)
            elif report_type == 'trend_analysis':
                return self._generate_trend_analysis_report(filtered_predictions, historical_df)
            elif report_type == 'predictive_insights':
                return self._generate_predictive_insights_report(filtered_predictions, historical_df)
            elif report_type == 'executive_summary':
                return self._generate_executive_summary_report(filtered_predictions, historical_df)
            elif report_type == 'employee_spotlight':
                return self._generate_employee_spotlight_report(filtered_predictions, historical_df)
            elif report_type == 'comparative_analysis':
                return self._generate_comparative_analysis_report(filtered_predictions, historical_df)
            else:
                st.error(f"Unknown report type: {report_type}")
                return pd.DataFrame()
                
        except Exception as e:
            st.error(f"Error generating report data: {str(e)}")
            return pd.DataFrame()
    
    def _generate_forecast_report(self, predictions_df, historical_df):
        """Generate productivity forecast report"""
        try:
            # Get latest historical data for comparison
            latest_historical = historical_df.groupby('employee_id').last().reset_index()
            
            # Merge with predictions
            forecast_report = predictions_df.merge(
                latest_historical[['employee_id', 'productivity_score', 'department']],
                on='employee_id',
                how='left',
                suffixes=('_predicted', '_current')
            )
            
            # Calculate productivity change
            forecast_report['productivity_change'] = (
                forecast_report['predicted_productivity'] - 
                forecast_report['productivity_score']
            )
            
            forecast_report['change_percentage'] = (
                forecast_report['productivity_change'] / 
                forecast_report['productivity_score'] * 100
            ).round(2)
            
            # Add trend indicators
            forecast_report['trend'] = forecast_report['productivity_change'].apply(
                lambda x: 'Improving' if x > 2 else 'Declining' if x < -2 else 'Stable'
            )
            
            # Select relevant columns
            report_columns = [
                'employee_id', 'department_predicted', 'prediction_date',
                'productivity_score', 'predicted_productivity', 'productivity_change',
                'change_percentage', 'trend', 'risk_level', 'confidence'
            ]
            
            return forecast_report[report_columns].rename(columns={
                'department_predicted': 'department',
                'productivity_score': 'current_productivity'
            })
            
        except Exception as e:
            st.error(f"Error generating forecast report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_risk_report(self, predictions_df, historical_df):
        """Generate risk analysis report"""
        try:
            # Focus on high and medium risk predictions
            risk_predictions = predictions_df[
                predictions_df['risk_level'].isin(['High', 'Medium'])
            ].copy()
            
            if len(risk_predictions) == 0:
                # Create empty report with message
                return pd.DataFrame({
                    'message': ['No high or medium risk predictions found in the selected period']
                })
            
            # Get historical performance for context
            employee_history = historical_df.groupby('employee_id')['productivity_score'].agg([
                'mean', 'std', 'min', 'max', 'count'
            ]).reset_index()
            
            # Merge with risk predictions
            risk_report = risk_predictions.merge(
                employee_history,
                on='employee_id',
                how='left'
            )
            
            # Calculate risk metrics
            risk_report['historical_avg'] = risk_report['mean'].round(2)
            risk_report['performance_volatility'] = risk_report['std'].round(2)
            risk_report['prediction_deviation'] = (
                risk_report['predicted_productivity'] - risk_report['mean']
            ).round(2)
            
            # Risk severity score (0-100)
            risk_report['risk_severity'] = (
                (100 - risk_report['predicted_productivity']) * 
                (1 + risk_report['std'] / 100)
            ).round(1)
            
            # Recommended actions
            risk_report['recommended_action'] = risk_report.apply(
                self._get_risk_recommendation, axis=1
            )
            
            # Select relevant columns
            report_columns = [
                'employee_id', 'department', 'prediction_date', 'predicted_productivity',
                'risk_level', 'risk_severity', 'historical_avg', 'performance_volatility',
                'prediction_deviation', 'recommended_action'
            ]
            
            return risk_report[report_columns]
            
        except Exception as e:
            st.error(f"Error generating risk report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_performance_report(self, predictions_df, historical_df):
        """Generate performance summary report"""
        try:
            # Employee-level summary
            employee_summary = predictions_df.groupby('employee_id').agg({
                'predicted_productivity': ['mean', 'min', 'max'],
                'risk_level': lambda x: (x == 'High').sum(),
                'confidence': 'mean'
            }).round(2)
            
            # Flatten column names
            employee_summary.columns = [
                'avg_predicted_productivity', 'min_predicted_productivity',
                'max_predicted_productivity', 'high_risk_days', 'avg_confidence'
            ]
            employee_summary = employee_summary.reset_index()
            
            # Get historical performance
            historical_summary = historical_df.groupby('employee_id').agg({
                'productivity_score': ['mean', 'std'],
                'department': 'first'
            }).round(2)
            
            historical_summary.columns = ['historical_avg', 'historical_std', 'department']
            historical_summary = historical_summary.reset_index()
            
            # Merge summaries
            performance_report = employee_summary.merge(
                historical_summary,
                on='employee_id',
                how='left'
            )
            
            # Calculate performance metrics
            performance_report['predicted_vs_historical'] = (
                performance_report['avg_predicted_productivity'] - 
                performance_report['historical_avg']
            ).round(2)
            
            performance_report['performance_stability'] = (
                100 - performance_report['historical_std']
            ).round(1)
            
            # Performance category
            performance_report['performance_category'] = performance_report.apply(
                self._categorize_performance, axis=1
            )
            
            # Reorder columns
            report_columns = [
                'employee_id', 'department', 'historical_avg', 'avg_predicted_productivity',
                'predicted_vs_historical', 'performance_stability', 'high_risk_days',
                'performance_category', 'avg_confidence'
            ]
            
            return performance_report[report_columns]
            
        except Exception as e:
            st.error(f"Error generating performance report: {str(e)}")
            return pd.DataFrame()
    
    def _get_risk_recommendation(self, row):
        """Get recommended action based on risk level and metrics"""
        if row['risk_level'] == 'High':
            if row['prediction_deviation'] < -10:
                return 'Immediate intervention required - significant decline predicted'
            else:
                return 'Schedule one-on-one meeting and provide additional support'
        elif row['risk_level'] == 'Medium':
            if row['performance_volatility'] > 15:
                return 'Monitor closely - high performance volatility detected'
            else:
                return 'Provide additional training or resources'
        else:
            return 'Continue current management approach'
    
    def _categorize_performance(self, row):
        """Categorize employee performance"""
        if row['avg_predicted_productivity'] >= 90:
            return 'High Performer'
        elif row['avg_predicted_productivity'] >= 80:
            return 'Good Performer'
        elif row['avg_predicted_productivity'] >= 70:
            return 'Average Performer'
        else:
            return 'Needs Improvement'
    
    def generate_summary_statistics(self, report_df, report_type):
        """
        Generate summary statistics for the report
        
        Args:
            report_df: Report DataFrame
            report_type: Type of report
            
        Returns:
            Dictionary with summary statistics
        """
        try:
            if len(report_df) == 0:
                return {'total_records': 0}
            
            summary = {'total_records': len(report_df)}
            
            if report_type == 'Productivity Forecast':
                if 'predicted_productivity' in report_df.columns:
                    summary.update({
                        'avg_predicted_productivity': f"{report_df['predicted_productivity'].mean():.1f}",
                        'employees_improving': len(report_df[report_df['trend'] == 'Improving']),
                        'employees_declining': len(report_df[report_df['trend'] == 'Declining']),
                        'prediction_period_days': (report_df['prediction_date'].max() - report_df['prediction_date'].min()).days + 1
                    })
            
            elif report_type == 'Risk Analysis':
                if 'risk_level' in report_df.columns:
                    summary.update({
                        'high_risk_predictions': len(report_df[report_df['risk_level'] == 'High']),
                        'medium_risk_predictions': len(report_df[report_df['risk_level'] == 'Medium']),
                        'avg_risk_severity': f"{report_df['risk_severity'].mean():.1f}" if 'risk_severity' in report_df.columns else 'N/A'
                    })
            
            elif report_type == 'Performance Summary':
                if 'performance_category' in report_df.columns:
                    summary.update({
                        'high_performers': len(report_df[report_df['performance_category'] == 'High Performer']),
                        'employees_needing_improvement': len(report_df[report_df['performance_category'] == 'Needs Improvement']),
                        'avg_predicted_productivity': f"{report_df['avg_predicted_productivity'].mean():.1f}" if 'avg_predicted_productivity' in report_df.columns else 'N/A'
                    })
            
            return summary
            
        except Exception as e:
            st.error(f"Error generating summary statistics: {str(e)}")
            return {'error': str(e)}
    
    def _generate_advanced_analytics_report(self, predictions_df, historical_df):
        """Generate advanced analytics report with deep insights"""
        try:
            analytics_data = []
            
            for employee_id in historical_df['employee_id'].unique():
                emp_data = historical_df[historical_df['employee_id'] == employee_id]
                emp_predictions = predictions_df[predictions_df['employee_id'] == employee_id]
                
                volatility = emp_data['productivity_score'].std()
                trend_slope = np.polyfit(range(len(emp_data)), emp_data['productivity_score'], 1)[0]
                consistency = 100 - (volatility / emp_data['productivity_score'].mean() * 100)
                
                analytics_data.append({
                    'employee_id': employee_id,
                    'volatility_score': volatility,
                    'trend_slope': trend_slope,
                    'consistency_score': consistency,
                    'performance_category': 'High' if emp_data['productivity_score'].mean() > 80 else 'Medium' if emp_data['productivity_score'].mean() > 60 else 'Low'
                })
            
            return pd.DataFrame(analytics_data)
        except Exception as e:
            st.error(f"Error generating advanced analytics report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_departmental_report(self, predictions_df, historical_df):
        """Generate departmental performance analysis"""
        try:
            if 'department' not in historical_df.columns:
                st.warning("Department information not available")
                return pd.DataFrame()
            
            dept_analysis = []
            for dept in historical_df['department'].unique():
                dept_historical = historical_df[historical_df['department'] == dept]
                avg_productivity = dept_historical['productivity_score'].mean()
                team_size = dept_historical['employee_id'].nunique()
                
                dept_analysis.append({
                    'department': dept,
                    'team_size': team_size,
                    'avg_productivity': avg_productivity,
                    'risk_level': 'High' if avg_productivity < 70 else 'Medium' if avg_productivity < 80 else 'Low'
                })
            
            return pd.DataFrame(dept_analysis)
        except Exception as e:
            st.error(f"Error generating departmental report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_trend_analysis_report(self, predictions_df, historical_df):
        """Generate trend analysis report"""
        try:
            historical_df['date'] = pd.to_datetime(historical_df['date'])
            daily_avg = historical_df.groupby('date')['productivity_score'].mean().reset_index()
            daily_avg['day_of_week'] = daily_avg['date'].dt.dayofweek
            daily_avg['month'] = daily_avg['date'].dt.month
            
            trend_data = []
            weekly_pattern = daily_avg.groupby('day_of_week')['productivity_score'].mean()
            
            for day in range(7):
                day_name = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][day]
                avg_productivity = weekly_pattern.iloc[day] if day < len(weekly_pattern) else 0
                trend_data.append({
                    'period_type': 'Weekly',
                    'period_name': day_name,
                    'avg_productivity': avg_productivity
                })
            
            return pd.DataFrame(trend_data)
        except Exception as e:
            st.error(f"Error generating trend analysis report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_predictive_insights_report(self, predictions_df, historical_df):
        """Generate predictive insights report"""
        try:
            insights_data = []
            
            for employee_id in predictions_df['employee_id'].unique():
                emp_historical = historical_df[historical_df['employee_id'] == employee_id]
                emp_predictions = predictions_df[predictions_df['employee_id'] == employee_id]
                
                if emp_historical.empty or emp_predictions.empty:
                    continue
                
                current_avg = emp_historical['productivity_score'].mean()
                predicted_avg = emp_predictions['predicted_productivity'].mean()
                predicted_change = predicted_avg - current_avg
                
                if predicted_change > 10:
                    insight = "Significant improvement expected"
                    recommendation = "Consider increased responsibilities"
                    priority = "Low"
                elif predicted_change < -10:
                    insight = "Performance decline predicted"
                    recommendation = "Immediate intervention needed"
                    priority = "High"
                else:
                    insight = "Stable performance expected"
                    recommendation = "Continue current approach"
                    priority = "Medium"
                
                insights_data.append({
                    'employee_id': employee_id,
                    'current_performance': current_avg,
                    'predicted_performance': predicted_avg,
                    'expected_change': predicted_change,
                    'insight': insight,
                    'recommendation': recommendation,
                    'priority': priority
                })
            
            return pd.DataFrame(insights_data)
        except Exception as e:
            st.error(f"Error generating predictive insights report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_executive_summary_report(self, predictions_df, historical_df):
        """Generate executive summary report"""
        try:
            total_employees = historical_df['employee_id'].nunique()
            avg_productivity = historical_df['productivity_score'].mean()
            
            high_performers = len(historical_df[historical_df['productivity_score'] >= 85]['employee_id'].unique())
            low_performers = len(historical_df[historical_df['productivity_score'] < 70]['employee_id'].unique())
            
            if not predictions_df.empty:
                predicted_avg = predictions_df['predicted_productivity'].mean()
                expected_change = predicted_avg - avg_productivity
            else:
                predicted_avg = avg_productivity
                expected_change = 0
            
            executive_data = [{
                'metric': 'Total Workforce',
                'current_value': total_employees,
                'status': 'Stable'
            }, {
                'metric': 'Average Productivity',
                'current_value': round(avg_productivity, 1),
                'predicted_value': round(predicted_avg, 1),
                'change': round(expected_change, 1),
                'status': 'Good' if avg_productivity > 75 else 'Needs Attention'
            }, {
                'metric': 'High Performers',
                'current_value': high_performers,
                'percentage': round(high_performers / total_employees * 100, 1) if total_employees > 0 else 0,
                'status': 'Excellent' if high_performers / total_employees > 0.4 else 'Good'
            }]
            
            return pd.DataFrame(executive_data)
        except Exception as e:
            st.error(f"Error generating executive summary report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_employee_spotlight_report(self, predictions_df, historical_df):
        """Generate employee spotlight report"""
        try:
            spotlight_data = []
            
            # Top performers
            top_performers = historical_df.groupby('employee_id')['productivity_score'].mean().nlargest(5)
            
            for emp_id, score in top_performers.items():
                spotlight_data.append({
                    'employee_id': emp_id,
                    'category': 'Top Performer',
                    'current_score': round(score, 1),
                    'status': 'Excellent',
                    'action_required': 'Recognition & Development'
                })
            
            # At-risk employees  
            at_risk = historical_df.groupby('employee_id')['productivity_score'].mean().nsmallest(5)
            
            for emp_id, score in at_risk.items():
                spotlight_data.append({
                    'employee_id': emp_id,
                    'category': 'Needs Attention',
                    'current_score': round(score, 1),
                    'status': 'At Risk',
                    'action_required': 'Immediate Support'
                })
            
            return pd.DataFrame(spotlight_data)
        except Exception as e:
            st.error(f"Error generating employee spotlight report: {str(e)}")
            return pd.DataFrame()
    
    def _generate_comparative_analysis_report(self, predictions_df, historical_df):
        """Generate comparative analysis report"""
        try:
            comparative_data = []
            
            # Department comparison if available
            if 'department' in historical_df.columns:
                dept_comparison = historical_df.groupby('department').agg({
                    'productivity_score': ['mean', 'std'],
                    'employee_id': 'nunique'
                }).round(2)
                
                for dept in dept_comparison.index:
                    comparative_data.append({
                        'comparison_type': 'Department',
                        'category': dept,
                        'avg_productivity': dept_comparison.loc[dept, ('productivity_score', 'mean')],
                        'employee_count': dept_comparison.loc[dept, ('employee_id', 'nunique')],
                        'performance_rating': 'Above Average' if dept_comparison.loc[dept, ('productivity_score', 'mean')] > historical_df['productivity_score'].mean() else 'Below Average'
                    })
            
            return pd.DataFrame(comparative_data)
        except Exception as e:
            st.error(f"Error generating comparative analysis report: {str(e)}")
            return pd.DataFrame()
