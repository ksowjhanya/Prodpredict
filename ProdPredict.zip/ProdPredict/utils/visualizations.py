import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import streamlit as st
import seaborn as sns
from datetime import datetime, timedelta

class DashboardVisualizer:
    """
    Visualization utilities for the productivity dashboard
    """
    
    def __init__(self):
        self.color_palette = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F']
        self.risk_colors = {'High': '#FF6B6B', 'Medium': '#FFD93D', 'Low': '#6BCF7F'}
        self.gradient_colors = {
            'primary': ['#667eea', '#764ba2'],
            'success': ['#11998e', '#38ef7d'],
            'warning': ['#f093fb', '#f5576c'],
            'info': ['#4facfe', '#00f2fe']
        }
    
    def plot_performance_trends(self, df):
        """
        Create performance trends visualization
        
        Args:
            df: DataFrame with performance data
            
        Returns:
            Plotly figure
        """
        try:
            # Aggregate daily performance
            daily_performance = df.groupby('date')['productivity_score'].agg(['mean', 'std']).reset_index()
            daily_performance['std'] = daily_performance['std'].fillna(0)
            
            fig = go.Figure()
            
            # Add mean line
            fig.add_trace(go.Scatter(
                x=daily_performance['date'],
                y=daily_performance['mean'],
                mode='lines+markers',
                name='Average Productivity',
                line=dict(color='#667eea', width=4),
                marker=dict(size=8, color='#764ba2')
            ))
            
            # Add confidence interval
            fig.add_trace(go.Scatter(
                x=daily_performance['date'],
                y=daily_performance['mean'] + daily_performance['std'],
                mode='lines',
                name='Upper Bound',
                line=dict(color='rgba(46, 134, 171, 0.3)', width=0),
                showlegend=False
            ))
            
            fig.add_trace(go.Scatter(
                x=daily_performance['date'],
                y=daily_performance['mean'] - daily_performance['std'],
                mode='lines',
                name='Lower Bound',
                line=dict(color='rgba(46, 134, 171, 0.3)', width=0),
                fill='tonexty',
                fillcolor='rgba(46, 134, 171, 0.2)',
                showlegend=False
            ))
            
            fig.update_layout(
                title='Daily Productivity Trends',
                xaxis_title='Date',
                yaxis_title='Productivity Score',
                hovermode='x unified',
                template='plotly_white'
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating performance trends plot: {str(e)}")
            return go.Figure()
    
    def plot_department_comparison(self, df):
        """
        Create department comparison visualization
        
        Args:
            df: DataFrame with department data
            
        Returns:
            Plotly figure
        """
        try:
            if 'department' not in df.columns:
                return go.Figure()
            
            # Calculate department statistics
            dept_stats = df.groupby('department')['productivity_score'].agg([
                'mean', 'median', 'std', 'count'
            ]).reset_index()
            dept_stats['std'] = dept_stats['std'].fillna(0)
            
            # Create subplot
            fig = make_subplots(
                rows=1, cols=2,
                subplot_titles=('Average Productivity by Department', 'Productivity Distribution'),
                specs=[[{"secondary_y": False}, {"type": "box"}]]
            )
            
            # Bar chart for averages
            fig.add_trace(
                go.Bar(
                    x=dept_stats['department'],
                    y=dept_stats['mean'],
                    error_y=dict(type='data', array=dept_stats['std']),
                    name='Average Productivity',
                    marker_color=self.color_palette[0:len(dept_stats)]
                ),
                row=1, col=1
            )
            
            # Box plot for distribution
            for dept in df['department'].unique():
                dept_data = df[df['department'] == dept]['productivity_score']
                fig.add_trace(
                    go.Box(
                        y=dept_data,
                        name=dept,
                        showlegend=False
                    ),
                    row=1, col=2
                )
            
            fig.update_layout(
                title='Department Performance Analysis',
                template='plotly_white',
                showlegend=False
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating department comparison plot: {str(e)}")
            return go.Figure()
    
    def plot_employee_performance(self, df):
        """
        Create individual employee performance visualization
        
        Args:
            df: DataFrame with employee data
            
        Returns:
            Plotly figure
        """
        try:
            # Calculate employee statistics
            employee_stats = df.groupby('employee_id')['productivity_score'].agg([
                'mean', 'std', 'count'
            ]).reset_index()
            employee_stats['std'] = employee_stats['std'].fillna(0)
            
            # Sort by average performance
            employee_stats = employee_stats.sort_values('mean', ascending=True)
            
            # Take top 20 employees for readability
            if len(employee_stats) > 20:
                employee_stats = employee_stats.tail(20)
            
            # Create horizontal bar chart
            fig = go.Figure()
            
            colors = ['#FF6B6B' if mean < 70 else '#FFD93D' if mean < 85 else '#6BCF7F' 
                     for mean in employee_stats['mean']]
            
            fig.add_trace(go.Bar(
                y=employee_stats['employee_id'],
                x=employee_stats['mean'],
                orientation='h',
                marker_color=colors,
                error_x=dict(type='data', array=employee_stats['std']),
                text=[f"{mean:.1f}" for mean in employee_stats['mean']],
                textposition='inside'
            ))
            
            fig.update_layout(
                title='Individual Employee Performance (Top 20)',
                xaxis_title='Average Productivity Score',
                yaxis_title='Employee ID',
                template='plotly_white',
                height=600
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating employee performance plot: {str(e)}")
            return go.Figure()
    
    def plot_correlation_matrix(self, df):
        """
        Create correlation matrix heatmap
        
        Args:
            df: DataFrame with numeric features
            
        Returns:
            Plotly figure
        """
        try:
            # Select numeric columns
            numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
            
            if len(numeric_cols) < 2:
                return go.Figure()
            
            # Calculate correlation matrix
            corr_matrix = df[numeric_cols].corr()
            
            # Create heatmap
            fig = go.Figure(data=go.Heatmap(
                z=corr_matrix.values,
                x=corr_matrix.columns,
                y=corr_matrix.columns,
                colorscale='RdBu',
                zmid=0,
                text=np.round(corr_matrix.values, 2),
                texttemplate="%{text}",
                textfont={"size": 10},
                hoverongaps=False
            ))
            
            fig.update_layout(
                title='Feature Correlation Matrix',
                template='plotly_white',
                width=800,
                height=600
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating correlation matrix: {str(e)}")
            return go.Figure()
    
    def create_advanced_dashboard(self, df, predictions_df=None):
        """Create comprehensive advanced analytics dashboard"""
        try:
            # Create subplot layout
            fig = make_subplots(
                rows=3, cols=2,
                subplot_titles=[
                    'Performance Distribution', 'Department Comparison',
                    'Productivity Trends Over Time', 'Risk Assessment Heatmap',
                    'Employee Performance Ranking', 'Prediction Accuracy'
                ],
                specs=[
                    [{"type": "histogram"}, {"type": "bar"}],
                    [{"type": "scatter"}, {"type": "heatmap"}],
                    [{"type": "bar"}, {"type": "scatter"}]
                ],
                vertical_spacing=0.1,
                horizontal_spacing=0.1
            )
            
            # 1. Performance Distribution
            fig.add_trace(
                go.Histogram(
                    x=df['productivity_score'],
                    nbinsx=20,
                    name='Distribution',
                    marker_color='lightblue'
                ),
                row=1, col=1
            )
            
            # 2. Department Comparison (if available)
            if 'department' in df.columns:
                dept_avg = df.groupby('department')['productivity_score'].mean().sort_values(ascending=True)
                fig.add_trace(
                    go.Bar(
                        x=dept_avg.values,
                        y=dept_avg.index,
                        orientation='h',
                        name='Dept Avg',
                        marker_color='lightgreen'
                    ),
                    row=1, col=2
                )
            
            # 3. Productivity Trends
            daily_trend = df.groupby('date')['productivity_score'].mean().reset_index()
            fig.add_trace(
                go.Scatter(
                    x=daily_trend['date'],
                    y=daily_trend['productivity_score'],
                    mode='lines+markers',
                    name='Daily Trend',
                    line=dict(color='orange')
                ),
                row=2, col=1
            )
            
            # 4. Risk Heatmap (simplified)
            if predictions_df is not None and 'risk_level' in predictions_df.columns:
                risk_matrix = predictions_df.pivot_table(
                    values='predicted_productivity',
                    index='employee_id',
                    columns='risk_level',
                    aggfunc='mean'
                ).fillna(0)
                
                if not risk_matrix.empty:
                    fig.add_trace(
                        go.Heatmap(
                            z=risk_matrix.values,
                            x=risk_matrix.columns,
                            y=risk_matrix.index,
                            colorscale='RdYlGn',
                            name='Risk Matrix'
                        ),
                        row=2, col=2
                    )
            
            # 5. Top Performers
            top_performers = df.groupby('employee_id')['productivity_score'].mean().nlargest(10)
            fig.add_trace(
                go.Bar(
                    x=top_performers.values,
                    y=top_performers.index,
                    orientation='h',
                    name='Top 10',
                    marker_color='gold'
                ),
                row=3, col=1
            )
            
            # 6. Prediction Accuracy (if available)
            if predictions_df is not None:
                fig.add_trace(
                    go.Scatter(
                        x=predictions_df['predicted_productivity'][:50],  # Limit for readability
                        y=predictions_df['confidence'][:50] if 'confidence' in predictions_df.columns else [0.8] * 50,
                        mode='markers',
                        name='Predictions',
                        marker=dict(
                            size=8,
                            color='purple',
                            opacity=0.6
                        )
                    ),
                    row=3, col=2
                )
            
            # Update layout
            fig.update_layout(
                height=900,
                title_text="Advanced Productivity Analytics Dashboard",
                showlegend=False,
                template='plotly_white'
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating advanced dashboard: {str(e)}")
            return go.Figure()
    
    def create_prediction_comparison_chart(self, historical_df, predictions_df):
        """Create detailed prediction vs historical comparison"""
        try:
            fig = make_subplots(
                rows=2, cols=2,
                subplot_titles=[
                    'Historical vs Predicted Performance',
                    'Prediction Confidence Distribution',
                    'Risk Level Analysis',
                    'Performance Trends Forecast'
                ],
                specs=[
                    [{"secondary_y": False}, {"type": "histogram"}],
                    [{"type": "pie"}, {"secondary_y": True}]
                ]
            )
            
            # 1. Historical vs Predicted scatter
            if not predictions_df.empty:
                # Get latest historical for each employee
                latest_historical = historical_df.groupby('employee_id')['productivity_score'].last().reset_index()
                comparison_data = predictions_df.merge(latest_historical, on='employee_id', how='left')
                
                fig.add_trace(
                    go.Scatter(
                        x=comparison_data['productivity_score'],
                        y=comparison_data['predicted_productivity'],
                        mode='markers',
                        name='Actual vs Predicted',
                        marker=dict(
                            size=8,
                            color=comparison_data['predicted_productivity'],
                            colorscale='Viridis',
                            showscale=True
                        ),
                        text=comparison_data['employee_id'],
                        hovertemplate='<b>%{text}</b><br>Historical: %{x}<br>Predicted: %{y}<extra></extra>'
                    ),
                    row=1, col=1
                )
                
                # Add perfect prediction line
                min_val = min(comparison_data['productivity_score'].min(), comparison_data['predicted_productivity'].min())
                max_val = max(comparison_data['productivity_score'].max(), comparison_data['predicted_productivity'].max())
                fig.add_trace(
                    go.Scatter(
                        x=[min_val, max_val],
                        y=[min_val, max_val],
                        mode='lines',
                        name='Perfect Prediction',
                        line=dict(dash='dash', color='red')
                    ),
                    row=1, col=1
                )
                
                # 2. Confidence distribution
                if 'confidence' in predictions_df.columns:
                    fig.add_trace(
                        go.Histogram(
                            x=predictions_df['confidence'],
                            nbinsx=15,
                            name='Confidence',
                            marker_color='lightcoral'
                        ),
                        row=1, col=2
                    )
                
                # 3. Risk level pie chart
                if 'risk_level' in predictions_df.columns:
                    risk_counts = predictions_df['risk_level'].value_counts()
                    fig.add_trace(
                        go.Pie(
                            labels=risk_counts.index,
                            values=risk_counts.values,
                            name='Risk Levels',
                            marker_colors=['green', 'yellow', 'red']
                        ),
                        row=2, col=1
                    )
                
                # 4. Trend forecast
                daily_historical = historical_df.groupby('date')['productivity_score'].mean().reset_index()
                daily_predicted = predictions_df.groupby('prediction_date')['predicted_productivity'].mean().reset_index()
                
                fig.add_trace(
                    go.Scatter(
                        x=daily_historical['date'],
                        y=daily_historical['productivity_score'],
                        mode='lines',
                        name='Historical Trend',
                        line=dict(color='blue')
                    ),
                    row=2, col=2
                )
                
                fig.add_trace(
                    go.Scatter(
                        x=daily_predicted['prediction_date'],
                        y=daily_predicted['predicted_productivity'],
                        mode='lines',
                        name='Predicted Trend',
                        line=dict(color='orange', dash='dash')
                    ),
                    row=2, col=2
                )
            
            fig.update_layout(
                height=800,
                title_text="Prediction Analysis Dashboard",
                showlegend=True,
                template='plotly_white'
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating prediction comparison chart: {str(e)}")
            return go.Figure()
    
    def create_employee_deep_dive(self, df, employee_id):
        """Create detailed analysis for specific employee"""
        try:
            emp_data = df[df['employee_id'] == employee_id].copy()
            if emp_data.empty:
                st.warning(f"No data found for employee {employee_id}")
                return go.Figure()
            
            emp_data = emp_data.sort_values('date')
            
            fig = make_subplots(
                rows=2, cols=2,
                subplot_titles=[
                    f'Performance Timeline - {employee_id}',
                    'Performance Distribution',
                    'Weekly Performance Pattern',
                    'Key Metrics Summary'
                ],
                specs=[
                    [{"secondary_y": True}, {"type": "histogram"}],
                    [{"type": "bar"}, {"type": "indicator"}]
                ]
            )
            
            # 1. Performance timeline with moving average
            fig.add_trace(
                go.Scatter(
                    x=emp_data['date'],
                    y=emp_data['productivity_score'],
                    mode='lines+markers',
                    name='Daily Performance',
                    line=dict(color='blue')
                ),
                row=1, col=1
            )
            
            # Add 7-day moving average
            emp_data['ma_7'] = emp_data['productivity_score'].rolling(window=7).mean()
            fig.add_trace(
                go.Scatter(
                    x=emp_data['date'],
                    y=emp_data['ma_7'],
                    mode='lines',
                    name='7-Day Moving Average',
                    line=dict(color='red', width=3)
                ),
                row=1, col=1
            )
            
            # 2. Performance distribution
            fig.add_trace(
                go.Histogram(
                    x=emp_data['productivity_score'],
                    nbinsx=15,
                    name='Distribution',
                    marker_color='lightgreen'
                ),
                row=1, col=2
            )
            
            # 3. Weekly pattern
            emp_data['day_of_week'] = emp_data['date'].dt.day_name()
            weekly_avg = emp_data.groupby('day_of_week')['productivity_score'].mean()
            day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            weekly_avg = weekly_avg.reindex([day for day in day_order if day in weekly_avg.index])
            
            fig.add_trace(
                go.Bar(
                    x=weekly_avg.index,
                    y=weekly_avg.values,
                    name='Weekly Pattern',
                    marker_color='orange'
                ),
                row=2, col=1
            )
            
            # 4. Key metrics
            avg_performance = emp_data['productivity_score'].mean()
            performance_std = emp_data['productivity_score'].std()
            trend_slope = np.polyfit(range(len(emp_data)), emp_data['productivity_score'], 1)[0]
            
            fig.add_trace(
                go.Indicator(
                    mode="gauge+number+delta",
                    value=avg_performance,
                    domain={'x': [0, 1], 'y': [0, 1]},
                    title={'text': "Avg Performance"},
                    delta={'reference': 80},
                    gauge={
                        'axis': {'range': [None, 100]},
                        'bar': {'color': "darkblue"},
                        'steps': [
                            {'range': [0, 50], 'color': "lightgray"},
                            {'range': [50, 80], 'color': "gray"},
                            {'range': [80, 100], 'color': "lightgreen"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 90
                        }
                    }
                ),
                row=2, col=2
            )
            
            fig.update_layout(
                height=700,
                title_text=f"Employee Deep Dive Analysis: {employee_id}",
                showlegend=True,
                template='plotly_white'
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating employee deep dive: {str(e)}")
            return go.Figure()
    
    def plot_model_performance(self, y_true, y_pred):
        """
        Create model performance visualization
        
        Args:
            y_true: Actual values
            y_pred: Predicted values
            
        Returns:
            Plotly figure
        """
        try:
            # Create subplot
            fig = make_subplots(
                rows=1, cols=2,
                subplot_titles=('Actual vs Predicted', 'Residuals Plot')
            )
            
            # Actual vs Predicted scatter plot
            fig.add_trace(
                go.Scatter(
                    x=y_true,
                    y=y_pred,
                    mode='markers',
                    name='Predictions',
                    marker=dict(color='#2E86AB', size=6, opacity=0.6)
                ),
                row=1, col=1
            )
            
            # Perfect prediction line
            min_val = min(min(y_true), min(y_pred))
            max_val = max(max(y_true), max(y_pred))
            fig.add_trace(
                go.Scatter(
                    x=[min_val, max_val],
                    y=[min_val, max_val],
                    mode='lines',
                    name='Perfect Prediction',
                    line=dict(color='red', dash='dash')
                ),
                row=1, col=1
            )
            
            # Residuals plot
            residuals = y_true - y_pred
            fig.add_trace(
                go.Scatter(
                    x=y_pred,
                    y=residuals,
                    mode='markers',
                    name='Residuals',
                    marker=dict(color='#A8DADC', size=6, opacity=0.6)
                ),
                row=1, col=2
            )
            
            # Zero line for residuals
            fig.add_hline(y=0, line_dash="dash", line_color="red", row=1, col=2)
            
            fig.update_xaxes(title_text="Actual Values", row=1, col=1)
            fig.update_yaxes(title_text="Predicted Values", row=1, col=1)
            fig.update_xaxes(title_text="Predicted Values", row=1, col=2)
            fig.update_yaxes(title_text="Residuals", row=1, col=2)
            
            fig.update_layout(
                title='Model Performance Analysis',
                template='plotly_white',
                showlegend=False
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating model performance plot: {str(e)}")
            return go.Figure()
    
    def plot_predictions_timeline(self, predictions_df):
        """
        Create predictions timeline visualization
        
        Args:
            predictions_df: DataFrame with predictions
            
        Returns:
            Plotly figure
        """
        try:
            if predictions_df is None or len(predictions_df) == 0:
                return go.Figure()
            
            fig = go.Figure()
            
            # Color by risk level
            for risk_level in ['Low', 'Medium', 'High']:
                risk_data = predictions_df[predictions_df['risk_level'] == risk_level]
                if len(risk_data) > 0:
                    fig.add_trace(go.Scatter(
                        x=risk_data['prediction_date'],
                        y=risk_data['predicted_productivity'],
                        mode='markers',
                        name=f'{risk_level} Risk',
                        marker=dict(
                            color=self.risk_colors[risk_level],
                            size=8,
                            opacity=0.7
                        ),
                        text=risk_data['employee_id'],
                        hovertemplate=
                        '<b>%{text}</b><br>' +
                        'Date: %{x}<br>' +
                        'Predicted Productivity: %{y:.1f}<br>' +
                        'Risk Level: ' + risk_level +
                        '<extra></extra>'
                    ))
            
            fig.update_layout(
                title='Productivity Predictions Timeline',
                xaxis_title='Prediction Date',
                yaxis_title='Predicted Productivity Score',
                template='plotly_white',
                hovermode='closest'
            )
            
            return fig
            
        except Exception as e:
            st.error(f"Error creating predictions timeline: {str(e)}")
            return go.Figure()
